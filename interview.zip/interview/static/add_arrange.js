jQuery(function($) {
	var fieldsTpl = '<div class="wrapper">\
						{{#fields}}\
							<div class="form-group">\
								<label for="{{label}}" class="col-sm-2 control-label">{{text}}</label>\
								<div class="col-sm-10">\
									{{#isInput}}\
										<input formnovalidate="formnovalidate" {{#required}}required="required"{{/required}} type="{{type}}" class="form-control {{label}}" name="{{name}}" placeholder="{{placeHolder}}">\
									{{/isInput}}\
									{{#isSelect}}\
										<select name="{{name}}" {{#required}}required="required"{{/required}} class="{{label}} form-control">\
									      	{{#options}}\
										      	<option value="{{value}}">{{text}}</option>\
									      	{{/options}}\
								    	</select>\
									{{/isSelect}}\
									{{#isTextArea}}\
										<textarea {{#required}}required="required"{{/required}} name="{{name}}" rows="5" class="{{label}} form-control placeholder="{{placeHolder}}"></textarea>\
									{{/isTextArea}}\
								</div>\
							</div>\
					   {{/fields}}\
					    <div class="form-group">\
						    <div class="col-sm-offset-2 col-sm-10">\
						    <button type="button" class="btn btn-warning delete-arrange">\
						      	<span class="glyphicon glyphicon-minus-sign"></span>\
						    	删除此安排\
						    </button>\
						    </div>\
						</div>\
					</div>';
	var filedsView = {
		'fields': [
			{
				'label': 'place',
				'text': '面试地点',
				'name': 'place',
				'required': false,
				'isInput': {					
					'type': 'text',
					'placeHolder': '北京'
				}
			},
			{
				'label': 'method',
				'text': '面试方式',
				'name': 'method',
				'required': false,
				'isInput': {					
					'type': 'text',
					'placeHolder': '面谈'
				}
			},
			{
				'label': 'interviewer',
				'text': '面试官',
				'name': 'interviewer',
				'required': true,
				'isInput': {					
					'type': 'text',
					'placeHolder': '张良'
				}
			},			
			{
				'label': 'interviewer-level',
				'text': '面试官级别',
				'name': 'interviewer_level',
				'required': true,
				'isSelect': {					
					'options': [
						{
							'value': '0',
							'text': '总裁/总监级别'
						},
						{
							'value': '1',
							'text': 'CEO'
						},
						{
							'value': '2',
							'text': '一般员工'
						}
					]
				}
			},
			{
				'label': 'time',
				'text': '面试时间',
				'name': 'time',
				'required': true,
				'isInput': {					
					'type': 'date',
					'placeHolder': ''
				}
			},
			{
				'label': 'evaluation',
				'text': '面试评价',
				'name': 'evaluation',
				'required': false,
				'isTextArea': {
					'placeHolder': '写入评价'
				}
			}
		]
	};

	Mustache.parse(fieldsTpl);

	$('.arrange-panel').on('click', '.add-arrange', function(e) {
		e.preventDefault();
		var $panel = $('.arrange-panel');
		if($panel.find('.wrapper').size() >= 5) {
			alert('面试次数不能超过5次')
		}else {
			$panel.find('.panel-body').prepend(Mustache.render(fieldsTpl, filedsView));	
		}
		
	}).on('click', '.delete-arrange', function(e) {
		e.preventDefault();
		if(confirm('确认要删除此次安排吗？')) {
			$(this).closest('.wrapper').remove();
		}		
	});

});